import pandas as pd
import re
import argparse
import random
import os
import warnings
from tqdm import *
warnings.filterwarnings("ignore")
parser=argparse.ArgumentParser()
parser.add_argument('--target',required=True)
parser.add_argument('--number',required=True)
parser.add_argument('--aug',required=True)
#parser.add_argument('--seed',required=True)
args=parser.parse_args()
f_list=[f for f in os.listdir(f'cross_valid_result{args.aug[0]}') if f.split('_')[0]==args.target]
columns=['stim','aug','cross','minsimu','avgdist','bestdist']
step_num=int(args.number)
steplist=[(i+1)*10 for i in range(0,step_num//10)]
for step in tqdm(steplist):
  df_result=pd.DataFrame(columns=columns)
  for f in f_list:
#  seed=f.split('_')[2][4:]
    aug=f.split('_')[2].split('.')[0][3:]
    cross=f.split('_')[1]
    df=pd.read_csv(f'cross_valid_result{args.aug[0]}/'+f,nrows=step)
    bestdist=min(df['dist'].to_list())
#  bestdist_sem=min(df['dist_sem'].to_list())
    df_best=df[df['dist']==bestdist]
#  df_best_sem=df[df['dist_sem']==bestdist_sem]
    mindist=df_best['minsimu'].to_list()[0]
#  mindist_sem=df_best['minsimu_sem'].to_list()[0]
#  mineva=df_best['mineva'].to_list()[0]
    avgdist=round(sum(df['dist'].to_list())/len(df['dist'].to_list()),3)
#  avgdist_sem=round(sum(df['dist_sem'].to_list())/len(df['dist_sem'].to_list()),3)
    df_result.loc[len(df_result)]=[args.target,aug,cross,mindist,str(avgdist),str(bestdist)]
    if aug=='0':
      for rand in ['rand_dist_overall','rand_dist_line']:
        mindist='null'
        mineva='null'
        randlist=df[rand].to_list()
        avgdist=round(sum(randlist)/len(randlist),3)
#      randlist_sem=df[rand+"_sem"].to_list()
#      avgdist_sem=round(sum(randlist_sem)/len(randlist_sem),3)
        bestdist=min(randlist)
#      bestdist_sem=min(randlist_sem)      
        df_result.loc[len(df_result)]=[args.target,rand,cross,mindist,str(avgdist),str(bestdist)]
  out=f'final_valid_cross_step{args.aug[0]}/'+args.target+'_'+str(step)+'_result.csv'
  df_result.to_csv(out,index=False)
