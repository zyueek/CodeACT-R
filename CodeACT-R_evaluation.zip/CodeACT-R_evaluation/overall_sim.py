import pandas as pd
import re
import argparse
import random
import os
import warnings
import statistics
import numpy as np
from tqdm import *
from path_seman import generate_path
from sti_with_backward import find_variable_and_statements_from_file
from collections import Counter
import math
warnings.filterwarnings("ignore")
def extend_unique_values_with_tolerance(stepall, tolerance,discount):
    # Sort the values to cluster them by proximity
    sorted_values = sorted(stepall)

    # Initialize clusters
    clusters = []
    current_cluster = [sorted_values[0]]

    # Form clusters based on tolerance
    for value in sorted_values[1:]:
        if value <= current_cluster[-1] * (1 + tolerance):
            current_cluster.append(value)
        else:
            clusters.append(current_cluster)
            current_cluster = [value]
    clusters.append(current_cluster)

    # Count occurrences within each cluster
    unique_values = []
    for cluster in clusters:
        counts = Counter(cluster)
        for number, count in counts.items():
            if count > 3:
                unique_values.extend([number] * (count // discount))
            else:
                unique_values.extend([number] * count)

    return unique_values

def set_step_aug(df,step_length,evaselect):
# find the distribution of evaluation pid scan length to set the simulation step
  avglength=sum(len(sublist) for sublist in evaselect) / len(evaselect)
  dev=sum([abs(len(sublist) - avglength) for sublist in evaselect])/len(evaselect)/2
#  print(avglength,dev)
  if len(evaselect)==1:
    avglength=len(evaselect[0])
    dev=0.5*len(evaselect[0])
  stepall=step_length
#  step=random.choice(random.choice(stepall))
  chosen_value = random.gauss(avglength, dev)
  closest_val = min(stepall, key=lambda x: abs(x - chosen_value))
#  print(closest_val)
#  print(stepall)
  return closest_val
def set_step_zero(df,train_complexity,test_complexity):
  stepall=[]
  stepsti=[]
  complex_map = {}
  for sti in list(set(df['stimuli'].to_list())):
    df_sti=df[df['stimuli']==sti]
    for s in list(set(df_sti['pid'].to_list())):
      df_pid=df_sti[df_sti['pid']==s]
      if(len(df_pid)<50):
#      df_pid['dense_rank'] = df_pid['complexity'].rank(method='dense').astype(int)
#      print(df_pid)
#      print(df_pid['complexity'].rank(method='dense'))
        complex_map[tuple(df_pid['complexity'].rank(method='dense').tolist())]=df_pid['line'].to_list()
#      stepsti.append(df_pid['line'].to_list())
        stepall.append(len(df_pid)) 
  counts = Counter(stepall)
#  unique_values = []
  comp_measure=test_complexity/ (train_complexity + test_complexity) 
  tolerance=0
  discount=int(round(comp_measure*10,0))
  unique_values=extend_unique_values_with_tolerance(stepall,tolerance,discount)
  unique_values=stepall
  unique_values.sort() 
#  print(unique_values)
  central_index =  comp_measure * len(unique_values)
  random_index = int(np.round(np.random.normal(loc=central_index, scale=len(unique_values)//4)))
  random_index = max(0, min(random_index, len(unique_values) - 1))
  selected_value = unique_values[random_index]
#  step=random.choice(random.choice(stepall))
#  print(stepall)
  comp_list=[list(key) for key, value in complex_map.items() if len(value) == selected_value]
#  print(unique_values)
  return selected_value,comp_list,comp_measure
def path_match(df_result,next_counts,df_t):
  feature=df_result['feature'].iloc[-1]
  controlnum=df_result['controlnum'].iloc[-1]
  complexity=df_result['complexity'].iloc[-1]
#  mix=str(controlnum)+"_"+feature+"_"+str(complexity)
  mix=str(controlnum)+"_"+feature
  if mix in next_counts.keys():
    next=next_counts[mix]
    keys = list(next.keys())
    weights = list(next.values())
    selected_key = random.choices(keys, weights=weights, k=1)[0]
#    print(selected_key)
    target_rows= df_t[(df_t['controlnum'] == int(selected_key.split("_")[0])) & (df_t['feature'] == selected_key.split("_")[1])]
#    print(target_rows)
    return target_rows,mix
  else:
    return pd.DataFrame(),0
def path_match_line(df_result,line_next,df_t):
  line=str(df_result['Line'].iloc[-1])
#  print(line,line_next.keys())
  if line in line_next.keys():
    next=line_next[line]
    keys = list(next.keys())
    weights = list(next.values())
    selected_key = int(random.choices(keys, weights=weights, k=1)[0])
#    print(selected_key)
#    print(selected_key)
    target_rows= df_t[df_t['Line'] == int(selected_key)] 
#    print(target_rows)
    return target_rows ,line
  else:
    return pd.DataFrame(),0
def select_chunks(lst, num_chunks):
    random.shuffle(lst)
    chunk_size = len(lst) // num_chunks
    remainder = len(lst) % num_chunks
    chunks = []
    start = 0
    for i in range(num_chunks):
        end = start + chunk_size + (1 if i < remainder else 0)
        chunks.append(lst[start:end])
        start = end
    return chunks
def select_chunks_re(lst, chunk_percent):
  chunks = []
  for _ in range(10):
    # Calculate 30% of the list length
    chunk_size = max(1, int(len(lst) * (chunk_percent/10)))  # Ensure at least one element is selected
    # Randomly select a chunk of 30% of the list
    chunk = random.sample(lst, chunk_size)
    chunks.append(chunk)
  return chunks
def select_chunks_half(lst, aug,seed):
    random.seed(seed)

    half_chunk_size = len(lst) // 2  # Use integer division for exact half

    half_chunk = random.sample(lst, half_chunk_size)

    remaining_elements = list(set(lst) - set(half_chunk))

    percentage = int(aug[0])
    if (aug[0]=='9'):
        percentage=int(aug[0])+1
    chunk_size = max(1, int(len(remaining_elements) * percentage / 10))  

    chunk = random.sample(remaining_elements, chunk_size)
    return [(half_chunk, chunk)]
def stm(pidselect):
  df_stm=pd.DataFrame(columns=column)
  for pid in pidselect:
    df_pid=df_e[df_e['pid']==pid]
    df_stm=pd.concat([df_stm,df_pid])
    df_stm.reset_index(drop=True, inplace=True)
  return df_stm
def simulate(df_mem,step,df_result,memtype,pidselect,next_counts,short_next,lines,step_comp,line_next,stepall):
  if(memtype=='long_re'):
    timestamp=step/float(stepall)    
    selected_rows = df_mem[(df_mem['section'] > timestamp*0.9) & (df_mem['section'] < timestamp*1.1)]
    selected_rows['distance'] = abs(selected_rows['section'] - timestamp)
    selected_rows['weight'] = 1 / (selected_rows['distance'] + 1)
    selected_rows['weight'] = selected_rows['weight'] / selected_rows['weight'].sum()
    if(len(selected_rows)==0):
      print("no timestamp: "+step+timestep)
    random_row = selected_rows.sample(n=1, weights='weight')
    controlnum=random_row.iloc[0,4]
    feature=random_row.iloc[0,5]
    complexity=random_row.iloc[0,6]
    corr_section=random_row.iloc[0,7]
    target_rows= df_t[(df_t['controlnum'] == controlnum) & (df_t['feature'] == feature)]
    if len(target_rows)==0:
      closest_index = (df_t['complexity'] - complexity).abs().idxmin()
      target_rows = df_t.loc[closest_index].to_list()
    elif len(target_rows)>1:
      closest_index = target_rows['complexity'].idxmax()
      target_rows = target_rows.loc[closest_index].to_list()
#    if(len(df_result)>=1 and target_rows[1]==df_result.iloc[-1,1]):
#    else:
    df_result.loc[len(df_result.index)]=target_rows+[corr_section,timestamp,memtype,'_'.join([str(p) for p in pidselect])]
  if(memtype=='long'):
    timestamp=step/float(stepall)  
    selected_rows = df_mem[(df_mem['section'] > timestamp-0.1) & (df_mem['section'] < timestamp+0.1)]
    df_t1['combined'] = list(zip(df_t1['controlnum'], df_t1['feature']))
    selected_rows['combined'] = list(zip(selected_rows['controlnum'], selected_rows['feature']))
    result = selected_rows[selected_rows['combined'].isin(df_t1['combined'])]
    random_row = result.sample(n=1,random_state=int(args.seed))    
    controlnum=random_row.iloc[0,4]
    feature=random_row.iloc[0,5]
    complexity=random_row.iloc[0,6]
    corr_section=random_row.iloc[0,7]
    target_rows= df_t[(df_t['controlnum'] == controlnum) & (df_t['feature'] == feature)]
    if len(target_rows)==0:
      closest_index = (df_t['complexity'] - complexity).abs().idxmin()
      target_rows = df_t.loc[closest_index].to_list()
    elif len(target_rows)>1:
      closest_index = target_rows['complexity'].idxmax()
      target_rows = target_rows.loc[closest_index].to_list()      
      print(closest_index)
    df_result.loc[len(df_result.index)]=target_rows+[corr_section,timestamp,memtype,'_'.join([str(p) for p in pidselect])]
  if(memtype=='null'):
    df_t1 = df_t.copy(deep=True)
    timestamp=step/float(stepall)    
    selected_rows = df_mem[(df_mem['section'] > timestamp-0.1) & (df_mem['section'] < timestamp+0.1)]
    df_t1['combined'] = list(zip(df_t1['controlnum'], df_t1['feature']))
    selected_rows['combined'] = list(zip(selected_rows['controlnum'], selected_rows['feature']))
#    print(selected_rows)
#    print(df_t)
# Check if the combined tuples in df1 exist in df2
    result = selected_rows[selected_rows['combined'].isin(df_t1['combined'])]
#    print(result)
#    selected_rows['distance'] = abs(selected_rows['section'] - timestamp)
#    selected_rows['weight'] = 1 / (selected_rows['distance'] + 1)
#    selected_rows['weight'] = selected_rows['weight'] / selected_rows['weight'].sum()

    if(len(selected_rows)==0):
      print("no timestamp: "+step+timestep)
#    random_row = selected_rows.sample(n=1, weights='weight',random_state=int(args.seed))
    random_row = result.sample(n=1,random_state=int(args.seed))
#    print(random_row)
    controlnum=random_row['controlnum'].iloc[0]
    feature=random_row['feature'].iloc[0]
    complexity=random_row['complexity'].iloc[0]
    corr_section=random_row['section'].iloc[0]
    target_rows= df_t[(df_t['controlnum'] == controlnum) & (df_t['feature'] == feature)]
    if len(target_rows)>1:
      closest_index = target_rows['complexity'].idxmax()
      target_rows = target_rows.loc[closest_index].to_list()
    else:
      target_rows=target_rows.iloc[0,:].to_list()
#    print(target_rows)
#    if len(target_rows)==0:
#      closest_index = (df_t['complexity'] - complexity).abs().idxmin()
#      target_rows = df_t.loc[closest_index].to_list()
#    elif len(target_rows)>1:
#      closest_index = target_rows['complexity'].idxmax()
#      target_rows = target_rows.loc[closest_index].to_list()
#    if(len(df_result)>=1 and target_rows[1]==df_result.iloc[-1,1]):
#    else:
#    print(target_rows)
    df_result.loc[len(df_result.index)]=target_rows+[corr_section,timestamp,memtype,'null']
  if(memtype=='short_path'):
    timestamp=step/float(stepall)    
#    print(timestamp)
    if len(df_result)==0:  
      df_t1 = df_t.copy(deep=True)   
      selected_rows = df_mem[(df_mem['section'] > timestamp-0.1) & (df_mem['section'] < timestamp+0.1)]
      df_t1['combined'] = list(zip(df_t1['controlnum'], df_t1['feature']))
      selected_rows['combined'] = list(zip(selected_rows['controlnum'], selected_rows['feature']))
      result = selected_rows[selected_rows['combined'].isin(df_t1['combined'])]
      if len(result)==0:
        return False  
      random_row = result.sample(n=1,random_state=int(args.seed))
      controlnum=random_row['controlnum'].iloc[0]
      feature=random_row['feature'].iloc[0]
      target_rows= df_t[(df_t['controlnum'] == controlnum) & (df_t['feature'] == feature)]
    else:
#      print(next_counts)
      target_rows,line=path_match_line(df_result,line_next,df_t)
#      target_rows,line=path_match(df_result,short_next,df_t)
    if len(target_rows)==0:
      return False
    elif len(target_rows)>=1:
      closest_index = target_rows['complexity'].idxmax()
      target_rows = target_rows.loc[closest_index].to_list()
#      print(closest_index)
#    print(target_rows)
    df_result.loc[len(df_result.index)]=target_rows+['0',timestamp,memtype,'_'.join([str(p) for p in pidselect])]
    return True
  if(memtype=='long_path'):
    timestamp=step/float(stepall)    
    selected_rows = df_mem[(df_mem['section'] > timestamp-0.1) & (df_mem['section'] < timestamp+0.1)]
    selected_rows['distance'] = abs(selected_rows['section'] - timestamp)
    selected_rows['weight'] = 1 / (selected_rows['distance'] + 1)
    selected_rows['weight'] = selected_rows['weight'] / selected_rows['weight'].sum()
    random_row = selected_rows.sample(n=1, weights='weight')
    controlnum=random_row.iloc[0,4]
    feature=random_row.iloc[0,5]
    complexity=random_row.iloc[0,6]
    corr_section=random_row.iloc[0,7]
    target_rows= df_t[(df_t['controlnum'] == controlnum) & (df_t['feature'] == feature)]    
    if (len(target_rows)==0 or len(target_rows)>1) and len(df_result)>1:
#      print(next_counts)
      target_rows,mix=path_match(df_result,next_counts,df_t)
    if len(target_rows)==0:
      closest_index = (df_t['complexity'] - complexity).abs().idxmin()
      target_rows = df_t.loc[closest_index].to_list()
#      if(len(target_rows)==0):
#        continue
    elif len(target_rows)>1:
      closest_index = target_rows['complexity'].idxmax()
      target_rows = target_rows.loc[closest_index].to_list()
#    if(len(df_result)>=1 and target_rows[1]==df_result.iloc[-1,1]):
#      continue
#    else:
#    print(target_rows)
#    if(len(target_rows)>0 and (len(df_result)<1 or (len(df_result)>=1 and target_rows[1]!=df_result.iloc[-1,1]))):
#      print(target_rows)
#      print(target_rows)
    df_result.loc[len(df_result.index)]=target_rows+[corr_section,timestamp,memtype,'null']
  if(memtype=='short_path1'):
    timestamp=step/float(stepall)    
#    print(timestamp)
    if len(df_result)==0:
      selected_rows = df_mem[(df_mem['section'] > timestamp-0.1) & (df_mem['section'] < timestamp+0.1)]
      if len(selected_rows)==0:
        return False
      selected_rows['distance'] = abs(selected_rows['section'] - timestamp)
      selected_rows['weight'] = 1 / (selected_rows['distance'] + 1)
      selected_rows['weight'] = selected_rows['weight'] / selected_rows['weight'].sum()
      random_row = selected_rows.sample(n=1, weights='weight')
      controlnum=random_row.iloc[0,4]
      feature=random_row.iloc[0,5]
      complexity=random_row.iloc[0,6]
      corr_section=random_row.iloc[0,7]
      target_rows= df_t[(df_t['controlnum'] == controlnum) & (df_t['feature'] == feature)]
    else:
#      print(next_counts)
      target_rows,line=path_match_line(df_result,line_next,df_t)
#      target_rows,line=path_match(df_result,short_next,df_t)
    if len(target_rows)==0:
#      print(i,line)
      return False
    elif len(target_rows)>1:
      closest_index = target_rows['complexity'].idxmax()
      target_rows = target_rows.loc[closest_index].to_list()
    df_result.loc[len(df_result.index)]=target_rows+['0',timestamp,memtype,'_'.join([str(p) for p in pidselect])]
    return True
  if(memtype=='quick'):
    timestamp=step/float(stepall)    
    variable, return_line, statements = find_variable_and_statements_from_file(lines)
#    print(statements)
#    print(variable, return_line, statements,i)
    if variable and (i<len(statements)-1):
      result_len=len(statements)
      target_line=statements[(-i)][1]
#      print(target_line)
      target_rows=df_t[(df_t['Line'] == target_line)].iloc[0].to_list()
#      print(target_rows,'asdasd')
#      print(df_t[(df_t['Line'] == target_line)].iloc[0])
      df_result.loc[len(df_result.index)]=target_rows+['0',timestamp,memtype,'null']
    else:
      closest_index = df_t['complexity'].idxmax()
      target_rows=df_t.loc[closest_index].to_list()
#      if((len(df_result)>0 and target_rows[1]!=df_result.iloc[-1,1]) or len(df_result)==0):
      df_result.loc[len(df_result.index)]=target_rows+['0',timestamp,memtype,'null']      
  if(memtype=='quick_comp'):
    timestamp=step/float(stepall)    
    complex_now=step_comp[i-1]
#    print(complex_now)
    df_t1=pd.read_csv(t+'_sem.csv')
    df_t1['rank'] = df_t1['complexity'].rank(method='dense').astype(int)
    df_t1 = df_t1.drop_duplicates(subset='Line', keep='first')
    total_rank = df_t1['rank'].sum()
    df_t1['probability'] = df_t1['rank'] / total_rank
    selected_row = df_t1.sample(n=1, weights='probability')
    target_rows = selected_row.drop(columns=['rank','probability'])
    target_rows=target_rows.iloc[0].to_list()
    df_result.loc[len(df_result.index)]=target_rows+['0',timestamp,memtype,'null']   
  if(memtype=='quick_aug'):
    timestamp=i/float(step)    
    variable, return_line, statements = find_variable_and_statements_from_file(lines)
#    print(statements)
    if variable and (i<len(statements)-1):
      result_len=len(statements)
      target_line=statements[(-i-1)][1]
      print(target_line)
      try:
        target_rows=df_t[(df_t['Line'] == target_line)].iloc[0,:].to_list()
      except:
        closest_index = df_t['complexity'].idxmax()
        target_rows=df_t.loc[closest_index].to_list()        
      df_result.loc[len(df_result.index)]=target_rows+['0',timestamp,memtype,'_'.join([str(p) for p in pidselect])]
    else:
      closest_index = df_t['complexity'].idxmax()
      target_rows=df_t.loc[closest_index].to_list()
#      if(len(df_result)==0 or target_rows[1]!=df_result.iloc[-1,1]  or len(df_result)==0):
      df_result.loc[len(df_result.index)]=target_rows+['0',timestamp,memtype,'_'.join([str(p) for p in pidselect])]   
#      print(lines)
  if(memtype=='quick_aug_comp'):
    timestamp=step/float(stepall)    
#    complex_now=step_comp[i-1]
#    print(complex_now)
    df_t1=pd.read_csv(t+'_sem.csv')
    df_t1['rank'] = df_t1['complexity'].rank(method='dense').astype(int)
    df_t1 = df_t1.drop_duplicates(subset='Line', keep='first')
    total_rank = df_t1['rank'].sum()
    df_t1['probability'] = df_t1['rank'] / total_rank
    selected_row = df_t1.sample(n=1, weights='probability')
    target_rows = selected_row.drop(columns=['rank','probability'])
    target_rows=target_rows.iloc[0].to_list()
    df_result.loc[len(df_result.index)]=target_rows+['0',timestamp,memtype,'_'.join([str(p) for p in pidselect])] 
def train_complexity(slist):
  train_complexity=0
  for stim in slist:
    df_sem=pd.read_csv(stim+'_sem.csv')
    unique_df = df_sem.drop_duplicates(subset='Line')
    total_sum = unique_df['complexity'].sum()
    train_complexity+=total_sum
#  print(train_complexity)
  return round(train_complexity/len(slist),2)
def action1():
    simulate(df, i, df_result, 'quick', 'null', next_counts, 0, lines, step_comp,line_next,step)
def action2():
    simulate(df, i, df_result, 'quick_comp', 'null', next_counts, 0, lines, step_comp,line_next,step)
def action3():
    simulate(df, i, df_result, 'quick_aug',pidselect,next_counts,0,lines,step_comp,line_next,step)
def action4():
    simulate(df, i, df_result, 'quick_aug_comp', pidselect,next_counts,0,lines,step_comp,line_next,step)
parser=argparse.ArgumentParser()
parser.add_argument('--number',required=True)
parser.add_argument('--s_list')
parser.add_argument('--t')
parser.add_argument('--seed',required=True)
parser.add_argument('--aug')
parser.add_argument('--pattern',required=True)
args=parser.parse_args()
column=['token','line','column','semantic','controlnum','feature','complexity','section','stimuli','pid']
slist=args.s_list.split(' ')
#print(slist)
tlist=[args.t]
f_list=[f for f in os.listdir('all_scanpath_repeat') if (f.split('.')[0][-3:]=='all' and f.split('_')[1] in [i[4:] for i in slist])] 
train_complexity=train_complexity(slist)
seed_value = int(args.seed)
np.random.seed(seed_value)
augnum=args.aug
number=int(args.number)
random.seed(seed_value)
tname='x'.join([i[4:] for i in tlist])
df=pd.DataFrame(columns=column)
for f in f_list:
  df_f=pd.read_csv("all_scanpath_repeat/"+f)
  df=pd.concat([df,df_f])
  df.reset_index(drop=True, inplace=True)
if args.pattern=='aug':
  for t in tlist:
    target_stim=t+'_sem.csv'
    with open(t+'.cpp', 'r') as file:
      code = file.read()      
    lines = code.strip().split('\n')
    df_t=pd.read_csv(target_stim)
    df_e=pd.read_csv("all_scanpath_repeat/sti_"+str(t[4:])+"_all.csv")
    pidlist=list(set(df_e['pid'].to_list()))
    step_length=[]
    for sti in list(set(df['stimuli'].to_list())):
      df_sti=df[df['stimuli']==sti]
      for s in list(set(df_sti['pid'].to_list())):
        step_length.append(len(df_sti[df_sti['pid']==s]))    
    chunks_pair = select_chunks_half(pidlist, augnum,seed_value)
    for half_chunk, chunk in chunks_pair:
      print(half_chunk, chunk)
      pidselect = [j for j in pidlist if j in chunk]
      evaselect=[]
      df_stm=stm(pidselect)
      next_counts,short_next,line_next=generate_path(df,df_stm,5)
#      print(line_next)
      for pid in pidselect:
        evaselect.append(df_stm[df_stm['pid']==pid]['line'].to_list())
      for num in range(number):
        evalist=[]
        if len(evaselect)==0:
          continue
        step=set_step_aug(df,step_length,evaselect)
        print(step)
        step_comp=[]
 #       print(step)
#  print(step)
        columns=['node','Line','Column','semanic','controlnum','feature','complexity','corr_section','section','memtype','pidselect']
        df_result=pd.DataFrame(columns=columns)
        if(3<step<10):
          for i in range(1,step+1):
            simulate(df_stm,i,df_result,'short_path',pidselect,next_counts,short_next,lines,step_comp,line_next,step)

#            if(not simulate(df_stm,i,df_result,'short',pidselect,next_counts,short_next,lines,step_comp,line_next,step)):
#              try:
#                simulate(df,i,df_result,'long',pidselect,next_counts,short_next,lines,step_comp,line_next,step)
#              except:
#                continue
        elif(step<=3):
          for i in range(1,step+1):
#             simulate(df,i,df_result,'quick_aug',pidselect,next_counts,0,lines,step_comp,line_next,step)  
            choice = random.choices([action3, action4], [0.5,0.5])[0]
            choice()
        else:
          for i in range(1,step+1):
            simulate(df_stm,i,df_result,'short_path',pidselect,next_counts,short_next,lines,step_comp,line_next,step)
#            if(not simulate(df_stm,i,df_result,'short_path',pidselect,next_counts,short_next,lines,step_comp,line_next,step)):
#              try:
#                simulate(df,i,df_result,'long_path',pidselect,next_counts,short_next,lines,step_comp,line_next,step)
#              except:
#                continue        
#        print(t,augnum)
        out=f'cross_valid_simu{augnum[0]}/'+t+"_"+tname+"_"+str(num)+"_aug"+str(augnum)+"_chunk"+str(augnum[1])+"_seed"+str(seed_value)+"_simu.csv"
        df_result.to_csv(out,index=False)
if args.pattern=='zero':
  for t in tlist:
    with open(t+'.cpp', 'r') as file:
      code = file.read()      
    lines = code.strip().split('\n')
    target_stim=t+'_sem.csv'
    df_t=pd.read_csv(target_stim)
    unique_df = df_t.drop_duplicates(subset='Line')
    test_complexity= unique_df['complexity'].sum()
    next_counts=generate_path(df,0,0)
    line_next={}
#    print(next_counts)
    for num in range(int(args.number)):
      step,steplist,comp_measure=set_step_zero(df,train_complexity,test_complexity)
      step_comp=random.choice(steplist)
      print(step)
#      print(step,steplist)
      columns=['node','Line','Column','semanic','controlnum','feature','complexity','corr_section','section','memtype','pidselect']
      df_result=pd.DataFrame(columns=columns)
      if(step>20):
        for i in range(1,step+1):
          simulate(df,i,df_result,'null','null',next_counts,0,lines,step_comp,line_next,step)
      elif(step<=3):
        for i in range(1,step+1):
          choice = random.choices([action1, action2], [1-comp_measure,comp_measure])[0]
          choice()
#          simulate(df,i,df_result,'quick','null',next_counts,0,lines,step_comp)      
      else:
        for i in range(1,step+1):
          simulate(df,i,df_result,'null','null',next_counts,0,lines,step_comp,line_next,step)   
#      print(df_result)
      out='cross_valid_simu/'+t+"_"+tname+"_"+str(num)+"_aug"+'0'+"_chunk"+'0'+"_seed"+str(seed_value)+"_simu.csv"
#      print(df_result)
      df_result.to_csv(out,index=False)
# find the number of rare and normal for simulation
#      df_rare= df_stm.groupby('pid').filter(lambda x: len(x) < 3)
#      df_normal= df_stm.groupby('pid').filter(lambda x: len(x) >= 3)
#      rarenum=round(len(df_rare)/len(df_stm)*number,0)
#      normalnum=round(len(df_normal)/len(df_stm)*number,0)
#      print(rarenum,normalnum)
#      print(f"Chunk {i}: {chunk}")
    
    
  

