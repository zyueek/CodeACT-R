import subprocess
import itertools
import tqdm
from tqdm import *
number='300'
def get_rest_elements(pair, full_list):
    return [elem for elem in full_list if elem != pair]
#stimlist = ['stim13','stim17','stim21','stim24','stim1','stim2','stim15','stim16','stim19','stim22','stim5']
stimlist = ['stim24','stim1','stim2','stim15','stim16','stim19','stim22','stim5']
for p in tqdm(stimlist):
  r = get_rest_elements(p, stimlist)
  print(p)

  auglist={'21':'41','22':'42','23':'43','24':'44','25':'45'}
  print(auglist)
#  subprocess.run(['python','overall_sim.py','--number=20','--s1='+r[0],'--s2='+r[1],'--s3='+r[2],'--s4='+r[3],'--s5='+r[4],'--t1='+p,'--seed=40','--aug=0','--pattern=zero'])
  for aug,seed in auglist.items():
    
    subprocess.run(['python','overall_sim.py','--number='+number,'--s_list='+' '.join(r),'--t='+p,f'--seed={seed}',f'--aug={aug}','--pattern=aug'])
    subprocess.run(['python','cross_valid_eva.py','--s_list='+' '.join(r),'--t='+p,f'--seed={seed}','--aug='+aug])
for s in stimlist:
  subprocess.run(['python','cross_valid_result_step.py','--target='+s,'--number='+number,'--aug=21'])
subprocess.run(['python','cross_report_step.py','--target=final_valid_cross_step','--number='+number,'--aug=21'])
print('1')
for p in tqdm(stimlist):
  r = get_rest_elements(p, stimlist)
  print(p)
  auglist={'41':'41','42':'42','43':'43','44':'44','45':'45'}
  print(auglist)
#  subprocess.run(['python','overall_sim.py','--number=20','--s1='+r[0],'--s2='+r[1],'--s3='+r[2],'--s4='+r[3],'--s5='+r[4],'--t1='+p,'--seed=40','--aug=0','--pattern=zero'])
  for aug,seed in auglist.items():
    a=1
    subprocess.run(['python','overall_sim.py','--number='+number,'--s_list='+' '.join(r),'--t='+p,f'--seed={seed}',f'--aug={aug}','--pattern=aug'])
    subprocess.run(['python','cross_valid_eva.py','--s_list='+' '.join(r),'--t='+p,f'--seed={seed}','--aug='+aug])
for s in stimlist:
  subprocess.run(['python','cross_valid_result_step.py','--target='+s,'--number='+number,'--aug=41'])
subprocess.run(['python','cross_report_step.py','--target=final_valid_cross_step','--number='+number,'--aug=41'])
print('2')
for p in tqdm(stimlist):
  r = get_rest_elements(p, stimlist)
  print(p)
  auglist={'61':'41','62':'42','63':'43','64':'44','65':'45'}
  print(auglist)
#  subprocess.run(['python','overall_sim.py','--number=20','--s1='+r[0],'--s2='+r[1],'--s3='+r[2],'--s4='+r[3],'--s5='+r[4],'--t1='+p,'--seed=40','--aug=0','--pattern=zero'])
  for aug,seed in auglist.items():
    a=1
    subprocess.run(['python','overall_sim.py','--number='+number,'--s_list='+' '.join(r),'--t='+p,f'--seed={seed}',f'--aug={aug}','--pattern=aug'])
    subprocess.run(['python','cross_valid_eva.py','--s_list='+' '.join(r),'--t='+p,f'--seed={seed}','--aug='+aug])
for s in stimlist:
  subprocess.run(['python','cross_valid_result_step.py','--target='+s,'--number='+number,'--aug=61'])
subprocess.run(['python','cross_report_step.py','--target=final_valid_cross_step','--number='+number,'--aug=61'])
print('3')
for p in tqdm(stimlist):
  r = get_rest_elements(p, stimlist)
  print(p)
  auglist={'81':'41','82':'42','83':'43','84':'44','85':'45'}
  print(auglist)
#  subprocess.run(['python','overall_sim.py','--number=20','--s1='+r[0],'--s2='+r[1],'--s3='+r[2],'--s4='+r[3],'--s5='+r[4],'--t1='+p,'--seed=40','--aug=0','--pattern=zero'])
  for aug,seed in auglist.items():
    a=1
    subprocess.run(['python','overall_sim.py','--number='+number,'--s_list='+' '.join(r),'--t='+p,f'--seed={seed}',f'--aug={aug}','--pattern=aug'])
    subprocess.run(['python','cross_valid_eva.py','--s_list='+' '.join(r),'--t='+p,f'--seed={seed}','--aug='+aug])
for s in stimlist:
  subprocess.run(['python','cross_valid_result_step.py','--target='+s,'--number='+number,'--aug=81'])
subprocess.run(['python','cross_report_step.py','--target=final_valid_cross_step','--number='+number,'--aug=81'])
print('4')
for p in tqdm(stimlist):
  r = get_rest_elements(p, stimlist)
  print(p)
  auglist={'91':'41','92':'42','93':'43','94':'44','95':'45'}
  print(auglist)
#  subprocess.run(['python','overall_sim.py','--number=20','--s1='+r[0],'--s2='+r[1],'--s3='+r[2],'--s4='+r[3],'--s5='+r[4],'--t1='+p,'--seed=40','--aug=0','--pattern=zero'])
  for aug,seed in auglist.items():
    a=1
    subprocess.run(['python','overall_sim.py','--number='+number,'--s_list='+' '.join(r),'--t='+p,f'--seed={seed}',f'--aug={aug}','--pattern=aug'])
    subprocess.run(['python','cross_valid_eva.py','--s_list='+' '.join(r),'--t='+p,f'--seed={seed}','--aug='+aug])
for s in stimlist:
  subprocess.run(['python','cross_valid_result_step.py','--target='+s,'--number='+number,'--aug=91'])
subprocess.run(['python','cross_report_step.py','--target=final_valid_cross_step','--number='+number,'--aug=91'])
